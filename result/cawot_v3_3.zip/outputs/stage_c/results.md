# Results — t2i_R@1 (overall)

Each cell: mean ± std over seeds (n_seeds). Single-seed cells show the Wilson 95% CI for R@1. `—` = run missing.

| method | budget 4% |
|---|---|
| random | 79.02 [77.87,80.13] (1) |
| clipscore | 78.50 [77.34,79.62] (1) |
| kcenter | 79.52 [78.38,80.62] (1) |
| sw_cawot | 78.94 [77.79,80.05] (1) |
| proposed **(method)** | 78.94 [77.79,80.05] (1) |
| indices | 78.84 [77.69,79.95] (1) |

## Coverage / what's missing

✅ All method×budget cells present.

## Notes for a defensible claim
- Report **t2i** (text→image, the deployment direction) separately from i2t.
- Compare `proposed` against **every** baseline *and* **full_data** at each budget.
- Wilson CI needs only (R@1, n_pairs); for paired significance, dump per-query hit vectors from eval and add a paired permutation test.
- The coreset story is strongest at **low budget** (2–5%) on the **real** test set.
